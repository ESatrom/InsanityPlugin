/**
 * Classes dedicated to facilitating
 * {@link org.bukkit.configuration.Configuration configurations} to be read and
 * stored on the filesystem.
 */
package org.bukkit.configuration.file;
