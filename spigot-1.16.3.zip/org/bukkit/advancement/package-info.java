/**
 * Classes relevant to advancements.
 */
package org.bukkit.advancement;
