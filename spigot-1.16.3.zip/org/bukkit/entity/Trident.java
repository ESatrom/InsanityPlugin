package org.bukkit.entity;

/**
 * Represents a thrown trident.
 */
public interface Trident extends AbstractArrow { }
