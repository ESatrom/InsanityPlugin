package org.bukkit.entity;

/**
 * Represents a Water Mob
 */
public interface WaterMob extends Creature {}
