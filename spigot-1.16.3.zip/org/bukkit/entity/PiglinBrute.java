package org.bukkit.entity;

/**
 * Represents a Piglin Brute.
 */
public interface PiglinBrute extends PiglinAbstract { }
