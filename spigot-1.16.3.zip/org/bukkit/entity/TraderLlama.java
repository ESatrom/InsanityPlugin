package org.bukkit.entity;

/**
 * Represents a trader Llama.
 */
public interface TraderLlama extends Llama { }
