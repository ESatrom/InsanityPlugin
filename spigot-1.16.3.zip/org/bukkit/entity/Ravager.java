package org.bukkit.entity;

/**
 * Illager beast.
 */
public interface Ravager extends Raider { }
