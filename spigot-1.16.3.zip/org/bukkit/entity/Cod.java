
package org.bukkit.entity;

/**
 * Represents a cod fish.
 */
public interface Cod extends Fish { }
