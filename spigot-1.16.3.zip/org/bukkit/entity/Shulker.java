package org.bukkit.entity;

import org.bukkit.material.Colorable;

public interface Shulker extends Golem, Colorable {}
