package org.bukkit.entity;

/**
 * Represents a SkeletonHorse - variant of {@link AbstractHorse}.
 */
public interface SkeletonHorse extends AbstractHorse { }
