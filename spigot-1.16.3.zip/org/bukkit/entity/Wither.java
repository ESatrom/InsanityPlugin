package org.bukkit.entity;

/**
 * Represents a Wither boss
 */
public interface Wither extends Monster, Boss {
}
