package org.bukkit.entity;

/**
 * Represents a type of "Illager".
 */
public interface Illager extends Raider { }
