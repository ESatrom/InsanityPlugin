/**
 * Classes concerning an entity's persistent memory.
 *
 * Currently only relevant for Villagers.
 */
package org.bukkit.entity.memory;
