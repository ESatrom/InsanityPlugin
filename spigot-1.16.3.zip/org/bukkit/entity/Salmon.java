
package org.bukkit.entity;

/**
 * Represents a salmon fish.
 */
public interface Salmon extends Fish { }
