package org.bukkit.entity;

/**
 * Represents a turtle.
 */
public interface Turtle extends Animals { }
