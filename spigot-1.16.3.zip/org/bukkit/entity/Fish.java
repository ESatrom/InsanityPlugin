package org.bukkit.entity;

/**
 * Represents a fish entity.
 */
public interface Fish extends WaterMob { }
