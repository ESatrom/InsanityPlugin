package org.bukkit.entity;

/**
 * Represents a Squid.
 */
public interface Squid extends WaterMob {}
