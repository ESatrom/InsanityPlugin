package org.bukkit.entity;

/**
 * Represents a Pig.
 */
public interface Pig extends Steerable, Vehicle { }
