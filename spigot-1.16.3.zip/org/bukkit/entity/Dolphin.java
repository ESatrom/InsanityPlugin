package org.bukkit.entity;

public interface Dolphin extends WaterMob { }
