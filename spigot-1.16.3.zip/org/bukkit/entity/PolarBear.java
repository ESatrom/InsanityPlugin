package org.bukkit.entity;

/**
 * Represents a polar bear.
 */
public interface PolarBear extends Animals {}
