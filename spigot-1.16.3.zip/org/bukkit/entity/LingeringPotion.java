package org.bukkit.entity;

/**
 * Represents a thrown lingering potion bottle
 *
 * @deprecated lingering status depends on only on the potion item.
 */
public interface LingeringPotion extends ThrownPotion { }
