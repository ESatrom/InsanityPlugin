package org.bukkit.entity;

/**
 * @deprecated tipped status depends only on base potion type not being
 * UNCRAFTABLE and effects being empty.
 */
@Deprecated
public interface TippedArrow extends Arrow { }
