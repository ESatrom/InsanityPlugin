/**
 * Interfaces for various {@link org.bukkit.entity.Minecart} types.
 */
package org.bukkit.entity.minecart;

