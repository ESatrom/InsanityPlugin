package org.bukkit.entity;

/**
 * Drowned zombie.
 */
public interface Drowned extends Zombie { }
