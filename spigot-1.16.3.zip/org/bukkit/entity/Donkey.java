package org.bukkit.entity;

/**
 * Represents a Donkey - variant of {@link ChestedHorse}.
 */
public interface Donkey extends ChestedHorse { }
