package org.bukkit.entity;

/**
 * Represents an ElderGuardian - variant of {@link Guardian}.
 */
public interface ElderGuardian extends Guardian { }
