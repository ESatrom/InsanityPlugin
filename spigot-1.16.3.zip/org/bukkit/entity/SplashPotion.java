package org.bukkit.entity;

/**
 * Represents a thrown splash potion bottle
 *
 * @deprecated splash status depends on only on the potion item.
 */
@Deprecated
public interface SplashPotion extends ThrownPotion { }
