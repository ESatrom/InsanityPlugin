package org.bukkit.block.data.type;

import org.bukkit.block.data.Orientable;
import org.bukkit.block.data.Waterlogged;

public interface Chain extends Orientable, Waterlogged {
}
