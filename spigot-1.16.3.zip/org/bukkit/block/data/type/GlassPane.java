package org.bukkit.block.data.type;

import org.bukkit.block.data.MultipleFacing;
import org.bukkit.block.data.Waterlogged;

public interface GlassPane extends MultipleFacing, Waterlogged {
}
