/**
 * Specific BlockData classes relevant to only a given block or set of blocks.
 */
package org.bukkit.block.data.type;
