package org.bukkit.block.data.type;

import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.MultipleFacing;

/**
 * md_5's mixtape.
 */
public interface Fire extends Ageable, MultipleFacing {
}
