package org.bukkit.block;

/**
 * Represents a captured state of a jigsaw.
 */
public interface Jigsaw extends TileState { }
