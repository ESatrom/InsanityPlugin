package org.bukkit.block;

import org.bukkit.material.Colorable;

/**
 * Represents a captured state of a bed.
 * @deprecated does not provide useful information beyond the material itself
 */
@Deprecated
public interface Bed extends TileState, Colorable { }
