package org.bukkit.block;

import org.bukkit.Nameable;

/**
 * Represents a captured state of an enchanting table.
 */
public interface EnchantingTable extends TileState, Nameable { }
