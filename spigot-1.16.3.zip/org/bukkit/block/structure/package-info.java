/**
 * Classes relevant to structure blocks.
 */
package org.bukkit.block.structure;
