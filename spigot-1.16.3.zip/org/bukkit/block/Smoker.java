package org.bukkit.block;

/**
 * Represents a captured state of a smoker.
 */
public interface Smoker extends Furnace { }
