package org.bukkit.block;

/**
 * Represents a captured state of Bell.
 */
public interface Bell extends TileState { }
