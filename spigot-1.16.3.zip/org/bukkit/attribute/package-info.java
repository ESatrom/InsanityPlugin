/**
 * Classes relevant to attributes.
 */
package org.bukkit.attribute;
