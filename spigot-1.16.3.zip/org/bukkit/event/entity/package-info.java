/**
 * {@link org.bukkit.event.Event Events} relating to {@link
 * org.bukkit.entity.Entity entities}, excluding some directly referencing
 * some more specific entity types.
 */
package org.bukkit.event.entity;

