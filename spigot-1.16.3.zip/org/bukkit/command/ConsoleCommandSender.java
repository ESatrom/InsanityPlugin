package org.bukkit.command;

import org.bukkit.conversations.Conversable;

public interface ConsoleCommandSender extends CommandSender, Conversable {
}
